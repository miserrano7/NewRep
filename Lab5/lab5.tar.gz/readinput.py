
user=raw_input("Enter something:")
print("Your input was: " +user)                                     
