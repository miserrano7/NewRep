num=int(raw_input("Enter a number: "))
#int will convert the string input to int 
print"The num is:",
print (num)  
print (type(num))
#type will let us know what kind of input it is, just to make sure it is a number 
