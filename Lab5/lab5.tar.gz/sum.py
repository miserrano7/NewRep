add=0
for num in range(1000):
    if ((num%3==0) or (num%5==0)):
       add+=num
print "the sum of the numbers is:",
print  (add)
